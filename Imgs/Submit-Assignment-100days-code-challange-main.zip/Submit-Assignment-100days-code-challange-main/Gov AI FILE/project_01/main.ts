// console.log("Hello world !!");
// console.log("Hello chachu !!");
console.log("\n");


/*      ... Tuba don't change the code ...

_____tsc main.ts && node main.js (two commands at 1 time ) ____

Commands:-
1) tsc main.ts
2) node main.js
3) tsc --init
4) tsc -w
5) node main.js
_______________________________
Variable 3 types....
1)Let          ( let   main error ata hy )
2)var          ( var   main error nhi ata hy )
3)const        ( const main  ata hy )

______________________________________________________*/

let message = "Hello **** BJ *** TJ ***";
console.log(message);
console.log("\n");

message = "Hello world ??? ";
console.log(message);
console.log("\n");

/* ---Camel case--- */
let firstNname: string = "varible store as camelCase like this in brackets -> [ camelCase ]  ";
console.log(firstNname);
console.log("\n");


/* datatype  typeOf */
console.log(" Datatypes ");
firstNname = "[camelCase]"
console.log(firstNname);
console.log(typeof firstNname);
console.log("\n");

let num = 6;
    num = 4;
console.log(num);
console.log(typeof num);
console.log("\n");

let num3 = "Jan";
let num4 = "Chor_dooooo!!! ";
console.log(num3 + " " + num4);
console.log("\n\n");

/* Addition means  Add(+) */
let num_1 = 1;
    num_1 = 3;
console.log("Addition ",num_1 + num_1);

/* Subtraction means  Sub(-) */
let num2 = 10;
let num_2 = 30;
console.log("Subtraction ",num2 - num_2);


/* Divide means  divide(/) */
let num_3 = 10;
let num_4 = 30;
console.log("Divide ",num_3 / num_4);

/* Modules means  remainder (%)  */ 
let num_5 = 10;
let num_6 = 30;
console.log("Modules ",num_5 % num_6);


/* Exponential means  power (**)  */ 
let num_7 = 5;
let num_8 = 3;
console.log("Exponent ",num_7 ** num_8);
